# Nexyra-Server (Groq-Version)

Läuft als eigenständiger Node.js-Server. Solange dieser Server läuft, denkt
Nexyra autonom weiter — egal ob dein Handy gesperrt ist oder ein Browser-Tab
offen ist.

## 1. Lokal testen

```bash
npm install
export GROQ_API_KEY=dein-eigener-key
npm start
```

Dann im Browser: http://localhost:3000

Wichtig: **"lokal" heißt, es läuft nur, solange dein Computer an und der
Prozess gestartet ist.** Für "läuft wirklich immer, auch wenn du offline
bist" brauchst du einen Rechner, der dauerhaft läuft (siehe Punkt 3).

## 2. Woher kommt der API-Key?

Unter https://console.groq.com kannst du einen eigenen, kostenlosen API-Key
erstellen (Konto anlegen → API Keys → Create Key).

**Falls du vorher schon einen Groq-Key irgendwo geteilt/gepostet hast:**
lösche ihn dort in der Konsole und erstelle einen neuen. Ein Key, der einmal
öffentlich sichtbar war, sollte nie weiterverwendet werden.

**Kostenlose Stufe**: Groq bietet großzügige, aber begrenzte kostenlose
Anfragen pro Minute/Tag (die genauen Limits ändern sich gelegentlich —
aktuell einsehbar unter https://console.groq.com/settings/limits). Für ein
persönliches Projekt wie dieses reicht das normalerweise gut aus.

**Falls die Limits doch mal knapp werden:**
- `AUTONOM_MINUTEN` (Umgebungsvariable) erhöhen, z.B. `export AUTONOM_MINUTEN=60`
  für nur noch einen autonomen Gedanken pro Stunde.
- In `server.js` ein kleineres Modell eintragen, z.B. `llama-3.1-8b-instant`
  statt `llama-3.3-70b-versatile` (schneller, weniger Limit-Verbrauch, aber
  etwas einfachere Antworten).

## 3. Damit es wirklich läuft, wenn dein Handy aus ist

Der Server muss auf einem Gerät laufen, das durchgehend an ist. Optionen:

- **Ein alter Laptop / Raspberry Pi zuhause**, der dauerhaft läuft
  (kostenlos, aber du musst ihn selbst am Laufen halten)
- **Kostenloser Cloud-Tier**, z.B. Render.com (Free Web Service) oder
  Fly.io — beide haben kostenlose Stufen, können den Server aber bei
  Inaktivität "einschlafen lassen", was die autonome Schleife unterbricht,
  bis wieder eine Anfrage reinkommt
- **Günstiger VPS** (z.B. Hetzner, ca. 4€/Monat) — läuft garantiert
  durchgehend, zuverlässigste Variante

Sag mir, für welche Option du dich entscheidest — ich gebe dir dann die
konkreten Deploy-Schritte dafür.

## Sicherheit des Notausschalters

Es gibt im gesamten Server-Code genau eine Stelle, die `state.isOff`
verändert: die Route `POST /api/killswitch`, ausgelöst durch den Knopf im
Frontend. Kein Modellaufruf hat Zugriff auf eine Funktion, die diese Route
aufrufen könnte — Nexyra kann sich technisch nicht selbst abschalten oder
die Reaktivierung verhindern.
